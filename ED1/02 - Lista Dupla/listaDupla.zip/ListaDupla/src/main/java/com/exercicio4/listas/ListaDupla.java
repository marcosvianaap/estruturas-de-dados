package main.java.com.exercicio4.listas;


public class ListaDupla {
    private NoListaDupla primeiro;

   

    public ListaDupla() { 
        this.primeiro = null;
    }
    
   
    public void inserirInicio(int valor){
        NoListaDupla novo = new NoListaDupla();
        novo.setInfo(valor);
        novo.setProx(this.primeiro);
        novo.setAnt(null);
        if (this.primeiro != null) {
            this.primeiro.setAnt(novo);
        }
        this.primeiro = novo;
    }
    
    public void inserirFim(int valor) {
        NoListaDupla novo = new NoListaDupla();
        novo.setInfo(valor);
        novo.setProx(null);
        NoListaDupla ultimo = ultimo();
        if (ultimo != null) {
            ultimo.setProx(novo);
            novo.setAnt(ultimo);
        } else {
            novo.setAnt(null);
            this.primeiro = novo;
        }
    }

    @Override
    public String toString(){
        String s = "Lista: ";
        NoListaDupla aux = this.primeiro;
        while (aux != null){
            s = s + aux.getInfo() + " ";
            aux = aux.getProx();
        }
        return s;
    }   
    
    public boolean vazia() {
        return this.primeiro == null;
    }    
    
    public NoListaDupla busca(int v) {
        NoListaDupla atual = this.primeiro;
        while (atual != null && atual.getInfo() != v) {
            atual = atual.getProx();
        }
        return atual;      
    }
    
    
    public int comprimento() {
        int contador = 0;
        NoListaDupla atual = this.primeiro;
        while (atual != null) {
            contador++;
            atual = atual.getProx();
        }
        return contador;
    }
    
    public NoListaDupla ultimo() {
        if (this.primeiro == null) {
            return null;
        } else {
            NoListaDupla atual = this.primeiro;
            while (atual.getProx() != null) {
                atual = atual.getProx();
            }
            return atual;
        }
    }
    
    public void retira(int v) {
        NoListaDupla atual = this.primeiro;
        while (atual != null) {
            if (atual.getInfo() == v) {
                if (atual.getAnt() != null) {
                    atual.getAnt().setProx(atual.getProx());
                }
                if (atual.getProx() != null) {
                    atual.getProx().setAnt(atual.getAnt());
                }
                return;
            }
            atual = atual.getProx();
        }
    }
    
    public void libera() {
        NoListaDupla atual = this.primeiro;
        while (atual != null) {
            NoListaDupla proximo = atual.getProx();
            atual.setAnt(null);
            atual.setProx(null);
            atual = proximo;
        }
        this.primeiro = null;
    }
    
    public boolean verifica(ListaDupla lista1) {
        NoListaDupla atualThis = this.primeiro;
        NoListaDupla atualLista1 = lista1.primeiro;
        
        while (atualThis != null && atualLista1 != null) {
            if (atualThis.getInfo() != atualLista1.getInfo()) {
                return false;
            }
            atualThis = atualThis.getProx();
            atualLista1 = atualLista1.getProx();
        }
        
        if (atualThis == null && atualLista1 == null) {
            return true;
        } else {
            return false;
        }
    }  
    
}      
