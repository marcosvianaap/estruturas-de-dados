package main.java.com.exercicio4.listas;

public class main {
    public static void main(String[] args){
        ListaDupla teste = new ListaDupla();
        System.out.println("A Lista esta vazia ? " + teste.vazia() + "\n");
        
        teste.inserirInicio(9);
        teste.inserirInicio(6);
        teste.inserirInicio(5);
        teste.inserirInicio(4);
        teste.inserirInicio(3);
        teste.inserirInicio(2);
        teste.inserirInicio(1);
        
        // Checando se a lista está vazia
        System.out.println(teste);
        System.out.println("A Lista esta vazia ? " + teste.vazia());
        System.out.println("\n");
        
        
        // Método de busca
        NoListaDupla no = teste.busca(2);
        System.out.println("Buscar valor: " + no.getInfo());
        if (no != null) {
            System.out.println("Valor: " + no.getInfo() + " encontrado na lista");
        } else {
            System.out.println("Valor: não encontrado na lista.");
        }
        System.out.println("\n");
        
        
        // Método comprimento e método ultimo
        System.out.println("Quantidade atual de nó: " + teste.comprimento());        
        NoListaDupla ultimo1 = teste.ultimo();
        if (ultimo1 != null) {
            System.out.println("O ultimo valor da lista é: " + ultimo1.getInfo());
        } else {
            System.out.println("A lista esta vazia.");
        }        
        System.out.println("\n");
        
        
     
        // Teste Retira
        System.out.println("Retire o valor: 9");
        teste.retira(9);
        System.out.println(teste);
        System.out.println("Quantidade atual de nó: " + teste.comprimento());        
        NoListaDupla ultimo2 = teste.ultimo();
        if (ultimo2 != null) {
            System.out.println("O ultimo valor da lista é: " + ultimo2.getInfo());
        } else {
            System.out.println("A lista esta vazia.");
        }
        System.out.println("\n");
        
        // Teste Insere ao fim
        System.out.println("Insere o valor: 9");
        teste.inserirFim(9);
        System.out.println(teste);
        System.out.println("Quantidade atual de nó: " + teste.comprimento());
        NoListaDupla ultimo3 = teste.ultimo();
        if (ultimo3 != null) {
            System.out.println("O ultimo valor da lista é: " + ultimo3.getInfo());
        } else {
            System.out.println("A lista esta vazia.");
        }
        System.out.println("\n");
        
        ListaDupla teste1 = new ListaDupla();
    
        teste1.inserirInicio(5);
        teste1.inserirInicio(4);
        teste1.inserirInicio(3);
        teste1.inserirInicio(2);
        teste1.inserirInicio(1);
        
        System.out.println("==> : " + teste);
        System.out.println("==> : " + teste1);
        
        if(teste.verifica(teste1)){
            System.out.println("As listas são iguais.");
        } else {
            System.out.println("As listas são diferentes.");
        }
        
       //teste.libera();
       //System.out.println(teste); 
    }   
}
