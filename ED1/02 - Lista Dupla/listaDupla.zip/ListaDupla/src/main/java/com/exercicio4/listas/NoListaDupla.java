package main.java.com.exercicio4.listas;

public class NoListaDupla {
    private int info;
    private NoListaDupla prox;
    private NoListaDupla ant;

    public NoListaDupla() {
    }

    public int getInfo() {
        return this.info;
    }

    public void setInfo(int v) {
        this.info = v;
    }

    public NoListaDupla getProx() {
        return prox;
    }

    public void setProx(NoListaDupla prox) {
        this.prox = prox;
    }

    public NoListaDupla getAnt() {
        return ant;
    }

    public void setAnt(NoListaDupla ant) {
        this.ant = ant;
    }
}
